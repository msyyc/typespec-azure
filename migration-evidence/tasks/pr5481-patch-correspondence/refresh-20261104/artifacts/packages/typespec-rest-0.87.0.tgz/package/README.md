# @typespec/rest

TypeSpec REST protocol binding

## Install

```bash
npm install @typespec/rest
```

## Decorators

### TypeSpec.Rest

- [`@action`](#@action)
- [`@actionSeparator`](#@actionseparator)
- [`@autoRoute`](#@autoroute)
- [`@collectionAction`](#@collectionaction)
- [`@copyResourceKeyParameters`](#@copyresourcekeyparameters)
- [`@createsOrReplacesResource`](#@createsorreplacesresource)
- [`@createsOrUpdatesResource`](#@createsorupdatesresource)
- [`@createsResource`](#@createsresource)
- [`@deletesResource`](#@deletesresource)
- [`@listsResource`](#@listsresource)
- [`@parentResource`](#@parentresource)
- [`@readsResource`](#@readsresource)
- [`@resource`](#@resource)
- [`@segment`](#@segment)
- [`@segmentOf`](#@segmentof)
- [`@updatesResource`](#@updatesresource)

#### `@action`

Specify this operation is an action. (Scoped to a resource item /pets/{petId}/my-action)

```typespec
@TypeSpec.Rest.action(name?: valueof string)
```

##### Target

`Operation`

##### Parameters

| Name | Type             | Description                                                                   |
| ---- | ---------------- | ----------------------------------------------------------------------------- |
| name | `valueof string` | Name of the action. If not specified, the name of the operation will be used. |

#### `@actionSeparator`

Defines the separator string that is inserted before the action name in auto-generated routes for actions.

When applied to a namespace, the separator applies to all action operations in that namespace and its sub-namespaces.
When applied to an interface, the separator applies to all action operations in that interface and overrides any namespace-level separator.
When applied to an operation, the separator applies only to that operation and overrides any interface or namespace-level separator.

```typespec
@TypeSpec.Rest.actionSeparator(seperator: valueof "/" | ":" | "/:")
```

##### Target

`Operation | Interface | Namespace`

##### Parameters

| Name      | Type                         | Description                                                      |
| --------- | ---------------------------- | ---------------------------------------------------------------- |
| seperator | `valueof "/" \| ":" \| "/:"` | Seperator seperating the action segment from the rest of the url |

#### `@autoRoute`

This interface or operation should resolve its route automatically. To be used with resource types where the route segments area defined on the models.

```typespec
@TypeSpec.Rest.autoRoute
```

##### Target

`Interface | Operation`

##### Parameters

None

##### Examples

```typespec
@autoRoute
interface Pets {
  get(@segment("pets") @path id: string): void; //-> route: /pets/{id}
}
```

#### `@collectionAction`

Specify this operation is a collection action. (Scopped to a resource, /pets/my-action)

```typespec
@TypeSpec.Rest.collectionAction(resourceType: Model, name?: valueof string)
```

##### Target

`Operation`

##### Parameters

| Name         | Type             | Description                                                                   |
| ------------ | ---------------- | ----------------------------------------------------------------------------- |
| resourceType | `Model`          | Resource marked with `@resource`                                              |
| name         | `valueof string` | Name of the action. If not specified, the name of the operation will be used. |

#### `@copyResourceKeyParameters`

Copy the resource key parameters on the model

```typespec
@TypeSpec.Rest.copyResourceKeyParameters(filter?: valueof string)
```

##### Target

`Model`

##### Parameters

| Name   | Type             | Description                           |
| ------ | ---------------- | ------------------------------------- |
| filter | `valueof string` | Filter to exclude certain properties. |

#### `@createsOrReplacesResource`

Specify that this is a CreateOrReplace operation for a given resource.

```typespec
@TypeSpec.Rest.createsOrReplacesResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@createsOrUpdatesResource`

Specify that this is a CreatesOrUpdate operation for a given resource.

```typespec
@TypeSpec.Rest.createsOrUpdatesResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@createsResource`

Specify that this is a Create operation for a given resource.

```typespec
@TypeSpec.Rest.createsResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@deletesResource`

Specify that this is a Delete operation for a given resource.

```typespec
@TypeSpec.Rest.deletesResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@listsResource`

Specify that this is a List operation for a given resource.

```typespec
@TypeSpec.Rest.listsResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@parentResource`

Mark model as a child of the given parent resource.

```typespec
@TypeSpec.Rest.parentResource(parent: Model)
```

##### Target

`Model`

##### Parameters

| Name   | Type    | Description   |
| ------ | ------- | ------------- |
| parent | `Model` | Parent model. |

#### `@readsResource`

Specify that this is a Read operation for a given resource.

```typespec
@TypeSpec.Rest.readsResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

#### `@resource`

Mark this model as a resource type with a name.

```typespec
@TypeSpec.Rest.resource(collectionName: valueof string)
```

##### Target

`Model`

##### Parameters

| Name           | Type             | Description            |
| -------------- | ---------------- | ---------------------- |
| collectionName | `valueof string` | type's collection name |

#### `@segment`

Defines the preceding path segment for a `@path` parameter in auto-generated routes.

```typespec
@TypeSpec.Rest.segment(name: valueof string)
```

##### Target

`Model | ModelProperty | Operation`

##### Parameters

| Name | Type             | Description                                                                                    |
| ---- | ---------------- | ---------------------------------------------------------------------------------------------- |
| name | `valueof string` | Segment that will be inserted into the operation route before the path parameter's name field. |

##### Examples

```typespec
@autoRoute
interface Pets {
  get(@segment("pets") @path id: string): void; //-> route: /pets/{id}
}
```

#### `@segmentOf`

Returns the URL segment of a given model if it has `@segment` and `@key` decorator.

```typespec
@TypeSpec.Rest.segmentOf(type: Model)
```

##### Target

`Operation`

##### Parameters

| Name | Type    | Description  |
| ---- | ------- | ------------ |
| type | `Model` | Target model |

#### `@updatesResource`

Specify that this is a Update operation for a given resource.

```typespec
@TypeSpec.Rest.updatesResource(resourceType: Model)
```

##### Target

`Operation`

##### Parameters

| Name         | Type    | Description                      |
| ------------ | ------- | -------------------------------- |
| resourceType | `Model` | Resource marked with `@resource` |

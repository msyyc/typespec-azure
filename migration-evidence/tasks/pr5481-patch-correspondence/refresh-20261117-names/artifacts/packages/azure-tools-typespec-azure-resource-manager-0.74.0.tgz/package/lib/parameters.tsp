using Http;
using Rest;
using Azure.ResourceManager.Foundations;
using Azure.ResourceManager.Private;
using Azure.ResourceManager.CommonTypes;
using Azure.ResourceManager.CommonTypes.Private;

namespace Azure.ResourceManager;

/**
 * The default api-version parameter type.
 */
alias ApiVersionParameter = CommonTypes.ApiVersionParameter;

/**
 * The default subscriptionId parameter type.
 */
alias SubscriptionIdParameter = CommonTypes.SubscriptionIdParameter;

/**
 * The default ResourceGroup parameter type.
 */
alias ResourceGroupParameter = CommonTypes.ResourceGroupNameParameter;

/**
 * DEPRECATED - DO NOT USE
 * The default location parameter type.
 */
@doc("The default location parameter type.")
model LocationParameter {
  @path
  @minLength(1)
  @segment("locations")
  @doc("The location name.")
  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v3)
  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v4)
  @armCommonParameter("LocationParameter", Azure.ResourceManager.CommonTypes.Versions.v5)
  @resourceParameterBaseFor([ResourceHome.Location])
  location: string;
}

/** The default location parameter type. */
model LocationResourceParameter {
  /** The name of the Azure region. */
  @path
  @minLength(1)
  @segment("locations")
  @key
  location: Azure.Core.azureLocation;
}

/**
 * The location resource for tenant-based locations.  This can be used as a parent
 * resource for resource types that are homed in a tenant-based location.
 *
 * @example
 * ```typespec
 * @parentResource(TenantLocationResource)
 * model Employee is TrackedResource<EmployeeProperties> {
 *  ...ResourceNameParameter<Employee>
 * }
 * ```
 */
model TenantLocationResource is ArmLocationResource<"Tenant">;

/**
 * The location resource for subscription-based locations.  This can be used as a parent
 * resource for resource types that are homed in a subscription-based location.
 *
 * @example
 * ```typespec
 * @parentResource(SubscriptionLocationResource)
 * model Employee is TrackedResource<EmployeeProperties> {
 *  ...ResourceNameParameter<Employee>;
 * }
 * ```
 */
model SubscriptionLocationResource is ArmLocationResource<"Subscription">;

/**
 * The location resource for resourceGroup-based locations.  This can be used as a parent
 * resource for resource types that are homed in a resourceGroup-based location.
 */
model ResourceGroupLocationResource is ArmLocationResource<"ResourceGroup">;

/**
 * Template for ARM location resources.  Use the parameter to specify
 * the parent of the location resource.
 * @template BaseType The parent of the location, one of "Subscription", "Tenant", "ResourceGroup", or "Extension".
 *
 * @example
 * ```typespec
 * @parentResource(ArmLocationResource<"ResourceGroup">)
 * model Employee is TrackedResource<EmployeeProperties> {
 *  ...ResourceNameParameter<Employee>;
 * }
 * ```
 */
@friendlyName("Location")
@armVirtualResource
@resourceBaseType(BaseType)
model ArmLocationResource<
  BaseType extends "Tenant" | "Subscription" | "ResourceGroup" | "Location" | "Extension" = never
> {
  ...LocationResourceParameter;
}

/**
 * The default resourceUri parameter type.
 *
 * @example
 * ```typespec
 * model Employee {
 *  ...ResourceUriParameter;
 * }
 * ```
 */
@doc("The default resourceUri parameter type.")
model ResourceUriParameter {
  @path(#{ allowReserved: true })
  @doc("The fully qualified Azure Resource manager identifier of the resource.")
  @resourceParameterBaseFor([ResourceHome.Extension])
  resourceUri: string;
}

/**
 * The dynamic parameters of a resource instance - pass in the proper base type to indicate
 * where the resource is based.  The default is in a resource group
 * @template Resource The resource to get parameters for
 * @template BaseParameters The parameters representing the base Uri of the resource
 * @template Provider Optional. The provider namespace model for the resource.
 *
 * @example
 * ```typespec
 * op get(
 *  ...ResourceInstanceParameters<Employee>,
 * ): ArmResponse<EmployeeResponse> | ErrorResponse;
 * ```
 */
model ResourceInstanceParameters<
  Resource extends {},
  BaseParameters = DefaultBaseParameters<Resource>,
  Provider extends {} = ProviderNamespace<Resource>
> {
  ...BaseParameters;
  ...Provider;
  ...KeysOf<Resource>;
}

/**
 * The dynamic parameters of a list call for a resource instance - pass in the proper base type to indicate
 * where the list should take place.  The default is in a resource group
 * @template Resource The resource to get parameters for
 * @template BaseParameters The parameters representing the base Uri of the resource
 * @template Provider Optional. The provider namespace model for the resource.
 */
model ResourceParentParameters<
  Resource extends Foundations.SimpleResource,
  BaseParameters = DefaultBaseParameters<Resource>,
  Provider extends {} = ProviderNamespace<Resource>
> {
  ...BaseParameters;
  ...Provider;
  ...ParentKeysOf<Resource>;
}

/**
 * The dynamic parameters of a list call for an extension resource instance.
 * @template Resource The extension resource
 */
alias ExtensionResourceInstanceParameters<Resource extends Foundations.SimpleResource> = ResourceInstanceParameters<
  Resource,
  ExtensionBaseParameters
>;

/**
 * The dynamic parameters of a list call for a tenant resource instance.
 * @template Resource the tenant resource
 */
alias TenantInstanceParameters<Resource extends Foundations.SimpleResource> = ResourceInstanceParameters<
  Resource,
  TenantBaseParameters
>;

/**
 * Template used by ArmProviderAction templates.
 *
 * @example
 * ```typespec
 * op action is ArmProviderActionSync<Response = Employee, Scope = SubscriptionActionScope>;
 * ```
 */
@armVirtualResource
@subscriptionResource
model SubscriptionActionScope {
  @doc("Symbolic name of scope")
  @path
  @visibility(Lifecycle.Read)
  @key
  @segment("subscription")
  name: string;
}

/**
 * Template used by ArmTenantAction templates.
 *
 *  @example
 * ```typespec
 * op action is ArmProviderActionSync<Response = Employee, Scope = TenantActionScope>;
 * ```
 */
@armVirtualResource
@tenantResource
model TenantActionScope {
  @doc("Symbolic name of scope")
  @path
  @visibility(Lifecycle.Read)
  @key
  @segment("tenant")
  name: string;
}

/**
 * Scope for operation status endpoints at the tenant level with a location path segment.
 * Use with `GetResourceOperationStatus` to produce:
 * `GET /providers/{providerNamespace}/locations/{location}/operationStatuses/{operationId}`
 *
 * @example
 * ```typespec
 * op getStatus is GetResourceOperationStatus<ArmOperationStatus, TenantLocationActionScope>;
 * ```
 */
@armVirtualResource
@tenantResource
model TenantLocationActionScope {
  ...LocationResourceParameter;
}

/**
 * Scope for operation status endpoints at the subscription level with a location path segment.
 * Use with `GetResourceOperationStatus` to produce:
 * `GET /subscriptions/{subscriptionId}/providers/{providerNamespace}/locations/{location}/operationStatuses/{operationId}`
 *
 * @example
 * ```typespec
 * op getStatus is GetResourceOperationStatus<ArmOperationStatus, SubscriptionLocationActionScope>;
 * ```
 */
@armVirtualResource
@subscriptionResource
model SubscriptionLocationActionScope {
  ...LocationResourceParameter;
}

/**
 * Template used by ArmProviderAction templates. This produces following action route:
 * `/{resourceUri}/providers/Microsoft.SomeRP/someAction`
 */
@armVirtualResource
@extensionResource
model ExtensionResourceActionScope {
  @doc("Symbolic name of scope")
  @path
  @visibility(Lifecycle.Read)
  @key
  @segment("extensionresource")
  name: string;
}

/**
 * Template used by ArmProviderAction templates. This produces following action route:
 * `/{scope}/providers/Microsoft.SomeRP/someAction`
 * @template StringType The type of the scope name parameter, defaults to string.
 */
model ExtensionActionScope<StringType extends string = string>
  is Extension.ScopeParameter<StringType>;

/**
 * Standard list parameter $top, allows the user to control the total number of returned items.
 */
model ArmTopParameter {
  @query("$top")
  @doc("The total number of items to return.")
  top?: int64;
}

/**
 * Standard list parameter $filter, allows the user to filter the results of a list operation.
 */
model ArmFilterParameter {
  @query("$filter")
  @doc("The OData filter expression to apply to the list operation.")
  filter?: string;
}

/**
 * List parameter $skip, allows the user to control the offset of returned items.
 */
model ArmSkipParameter {
  @query("$skip")
  @doc("The number of items to skip before starting to collect the result set.")
  skip?: int64;
}

/**
 * Standard list parameter $skiptoken, normally returned in the `nextLink` url of a page of items
 */
model SkipTokenParameter {
  @query("$skiptoken")
  @doc("An opaque value to use for pagination.")
  skipToken: string;
}

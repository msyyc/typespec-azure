import "@typespec/http";
import "@typespec/rest";
import "@typespec/versioning";
import "./traits.tsp";

using Http;
using Rest;
using Versioning;
using Azure.Core.Traits;
using Azure.Core.Traits.Private;

namespace Azure.Core;

/** A deployment's HTTP endpoint and OAuth authentication requirements. */
model AzureServiceConfiguration {
  /** The server URL or URL template, as accepted by `@server`. */
  endpoint: string;

  /** A reference to authentication models, an OR union, or an AND tuple, as accepted by `@useAuth`. */
  authentication: TypeRef<{} | Reflection.Union | {}[]>;

  /** A reference to the parameter model used in the endpoint URL template. */
  parameters?: TypeRef<Reflection.Model>;

  /** Description of the server. */
  description?: string;
}

/**
 * Azure Active Directory (AAD) Token Authentication Flow
 * @template AuthUrl The authorization URL.
 * @template TokenUrl The token URL.
 * @template Scopes A list of scopes the token applies to.
 */
model AadTokenAuthFlow<Scopes extends string[], AuthUrl extends string, TokenUrl extends string>
  extends TypeSpec.Http.AuthorizationCodeFlow {
  /** The OAuth2 flow type, always the authorization code flow. */
  type: OAuth2FlowType.authorizationCode;

  /** The authorization URL used to obtain an authorization code. */
  authorizationUrl: AuthUrl;

  /** The token URL used to exchange the authorization code for a token. */
  tokenUrl: TokenUrl;

  /** The list of scopes the token applies to. */
  scopes: Scopes;
}

/**
 * Azure Active Directory OAuth2 Flow
 * @template AuthUrl The authorization URL.
 * @template TokenUrl The token URL.
 * @template Scopes A list of scopes the token applies to.
 */
@doc("The Azure Active Directory OAuth2 Flow")
model AadOauth2Auth<
  Scopes extends string[],
  AuthUrl extends string = "https://login.microsoftonline.com/common/oauth2/authorize",
  TokenUrl extends string = "https://login.microsoftonline.com/common/oauth2/token"
> is OAuth2Auth<[AadTokenAuthFlow<Scopes, AuthUrl, TokenUrl>]>;

/**
 * Azure API Key Authentication using the "Ocp-Apim-Subscription-Key" hea
 */
@doc("Azure API Key Authentication")
model AzureApiKeyAuthentication is TypeSpec.Http.ApiKeyAuth<
  ApiKeyLocation.header,
  "Ocp-Apim-Subscription-Key"
>;

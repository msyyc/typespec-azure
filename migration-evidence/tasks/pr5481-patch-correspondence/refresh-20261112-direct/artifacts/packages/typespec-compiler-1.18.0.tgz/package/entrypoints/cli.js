/**
 * File serving as an entrypoint to resolve a local tsp install from a global install.
 * DO NOT MOVE or this will create a breaking change for user of global cli.
 */
import { runTypeSpecCli } from "../dist/src/core/cli/cli.js";

await runTypeSpecCli();
